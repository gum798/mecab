#ln -s /opt/syntax/mecab-ko-dic-2.1.1-20180720 mecab-ko-dic-2.1.1-20180720
nohup python3 -u mecab_api.py  > /dev/null 2> /dev/null & 

